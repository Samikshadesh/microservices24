package com.example.Hotelservice.exception;

import com.example.Hotelservice.payload.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHnadler extends Exception{
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponses>handleResourceNotfoundException(ResourceNotFoundException e){
        String msg = e.getMessage();
        ApiResponses response = ApiResponses.builder().message(msg).SUCCESS(true).status(HttpStatus.NOT_FOUND).build();
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);


    }

}
