package com.example.Hotelservice.payload;

import lombok.*;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Builder
public class ApiResponses {
    private String message;
    private boolean SUCCESS;
    private HttpStatus status;
}
