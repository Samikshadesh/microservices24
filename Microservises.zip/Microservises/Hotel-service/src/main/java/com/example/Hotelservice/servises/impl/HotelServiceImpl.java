package com.example.Hotelservice.servises.impl;

import com.example.Hotelservice.entities.Hotel;
import com.example.Hotelservice.repository.HotelRepository;
import com.example.Hotelservice.servises.HotelServiceInterface;
import com.example.Hotelservice.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelServiceImpl implements HotelServiceInterface {
    @Autowired
    HotelRepository hotelRepository;
    @Override
    public Hotel createHotel(Hotel hotel) {
//        String randomId = UUID.randomUUID().toString();
//        hotel.setId(randomId);
        return hotelRepository.save(hotel);
    }

    @Override
    public Hotel get(String id) {
        return hotelRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Resoucre Not found..!!"+id));
    }

    @Override
    public List<Hotel> getAll() {
        return hotelRepository.findAll();
    }

}
