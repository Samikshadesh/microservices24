package com.example.Hotelservice.controller;

import com.example.Hotelservice.entities.Hotel;
import com.example.Hotelservice.servises.HotelServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotel")
public class HotelController {
    @Autowired
    HotelServiceInterface  hotelServiceInterface;

    @PostMapping
    public ResponseEntity<Hotel>createHotel(@RequestBody Hotel hotel){
        Hotel hotel1= hotelServiceInterface.createHotel(hotel);
        return ResponseEntity.status(HttpStatus.CREATED).body(hotel1);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hotel>getById(@PathVariable String id){
        //Hotel hotel = hotelServiceInterface.get(id);
        return ResponseEntity.ok(hotelServiceInterface.get(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Hotel>>getAll(){
        return ResponseEntity.ok(hotelServiceInterface.getAll());

    }
}
