package com.example.Hotelservice.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.autoconfigure.web.WebProperties;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hotel {
    @Id
    //@GeneratedValue(Strategy = GenerationType.AUTO)
    //@GeneratedValue(strategy = GenerationType.AUTO)
    private String id;
    private String name;
    private String location;
    private String about;

}
