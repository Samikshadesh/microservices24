package com.example.Hotelservice.servises;

import com.example.Hotelservice.entities.Hotel;

import java.util.List;

public interface HotelServiceInterface {
    Hotel createHotel(Hotel hotel);
    Hotel get(String hotelId);

    List<Hotel>getAll();


}
