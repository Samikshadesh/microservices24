package com.example.productservice.controller;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwtService {
    public String autheticateAndGetToken(String username, String password){
        return null;

    }

}
