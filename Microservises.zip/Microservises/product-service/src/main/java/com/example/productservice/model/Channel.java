package com.example.productservice.model;

import java.util.ArrayList;
import java.util.List;

public class Channel {
   private List<Subscriber> ls = new ArrayList<>();
   private String title;

   public void subscribe(Subscriber sub){
       ls.add(sub);
   }

   public void unScribe(Subscriber sub){
       ls.remove(sub);
   }
   public void notifySubscriber(){
       for(Subscriber su: ls){
       su.update();
   }}
    public void upload(String title){
       this.title=title;
        notifySubscriber();
    }

}
