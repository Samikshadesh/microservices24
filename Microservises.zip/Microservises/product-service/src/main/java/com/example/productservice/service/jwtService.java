package com.example.productservice.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class jwtService {
    private static final String SECRETS = "";

    public String generateToken(String username){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("sam", map);
        return createToken(map,username);

    }

    private String createToken(Map<String, Object> map, String username) {
        return Jwts.builder()
                .setClaims(map)
                .setSubject(username)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis()+1000*60*30))
                .signWith(getSignKey, SignatureAlgorithm.HS256).compact();
    }
    private Key getSignKey(){
        byte[] keyBytes = Decoders.BASE64.decode(SECRETS);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
