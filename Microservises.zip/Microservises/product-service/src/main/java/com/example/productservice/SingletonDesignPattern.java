package com.example.productservice;

public class SingletonDesignPattern {
    public static void main(String[] args){

    }
}
