package com.example.Userservice.service.impl;

import com.example.Userservice.entity.Hotel;
import com.example.Userservice.entity.Rating;
import com.example.Userservice.entity.User;
import com.example.Userservice.exception.ResourceNotfFoundException;
import com.example.Userservice.external.services.HotelService;
import com.example.Userservice.external.services.RatingService;
import com.example.Userservice.repository.UserRepository;
import com.example.Userservice.service.UserserviceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
@Service
public class UserServiceImpl implements UserserviceInterface {
    @Autowired
    UserRepository userRepository;
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    RatingService ratingService;

    @Autowired
    HotelService hotelService;
    @Override
    public User saveall(User user) {
        String randomUUID = UUID.randomUUID().toString();
        user.setUserId(randomUUID);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public User getById(String userId) {
        User user = userRepository.findById(userId).orElseThrow(()->new ResourceNotfFoundException("User not found for given id: "+userId));
        //making fun like take id dynamic.Get Rating inside User.
        ArrayList rating = restTemplate.getForObject("http://localhost:8084/rating/UserId/145de12b-2fdd-4512-bfae-fa6df212767b",ArrayList.class);
       // List<Rating>rating = (List<Rating>) ratingService.getRating(user.getUserId());
        user.setRating(rating);
//        Hotel list = restTemplate.getForObject("http://localhost:8082/hotel/15309735-8813-4f78-be37-68d411c84dc1", Hotel.class);
//        //Hotel hotel = hotelService.getHotel();
//        user.setHotel(list);
        return user;
    }
}
