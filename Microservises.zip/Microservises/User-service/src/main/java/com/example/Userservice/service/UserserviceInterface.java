package com.example.Userservice.service;

import com.example.Userservice.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;
public interface UserserviceInterface {
    User saveall(User user);

    List<User> getAllUser();

    User getById(String userId);
}
