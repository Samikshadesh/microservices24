package com.example.Userservice.controller;

import com.example.Userservice.entity.User;
import com.example.Userservice.service.UserserviceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class Usercontroller {
    @Autowired(required=true)
    UserserviceInterface userservice;
    @PostMapping
    public ResponseEntity<User>createUser(@RequestBody User user){
        User user1 = userservice.saveall(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);

    }
    @GetMapping("/{userId}")
    public ResponseEntity<User>getUserById(@PathVariable String userId){
        User user1 = userservice.getById(userId);
        return ResponseEntity.ok(user1);

    }
    @GetMapping("/all")
    public ResponseEntity<List<User>>getAllUser(){
       List<User>ls= userservice.getAllUser();
       return ResponseEntity.ok(ls);
    }

}
