package com.example.Userservice.exception;

public class ResourceNotfFoundException extends RuntimeException{
    public ResourceNotfFoundException(){
        super("Resource not found exception!...");
    }

    public ResourceNotfFoundException(String str){
        super(str);
    }
}
