package com.example.Userservice.payload;

import lombok.*;
import org.springframework.http.HttpStatus;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Apiresponse {
    private String message;
    private boolean SUCCESS;
    private HttpStatus status;

}
