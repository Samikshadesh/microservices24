package com.example.Userservice.exception;

import com.example.Userservice.payload.Apiresponse;
import org.apache.coyote.Response;
import org.hibernate.annotations.NotFound;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
@ExceptionHandler(ResourceNotfFoundException.class)
    public ResponseEntity<Apiresponse> handleResourceNotFoundException(ResourceNotfFoundException ex){
    String msg = ex.getMessage();
    Apiresponse response = Apiresponse.builder().message(msg).SUCCESS(true).status(HttpStatus.NOT_FOUND).build();
    return new ResponseEntity<Apiresponse>(response, HttpStatus.NOT_FOUND);
}
}
