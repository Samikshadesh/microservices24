package com.example.Userservice.external.services;

import com.example.Userservice.entity.Rating;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "RATING-SERVICE")
public interface RatingService {

    @GetMapping("/rating/UserId/{ratingId}")
    Rating getRating(@PathVariable String ratingId);
}
