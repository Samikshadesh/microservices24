package com.example.Ratingservice.controller;

import com.example.Ratingservice.entities.Rating;
import com.example.Ratingservice.services.RatingServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rating")
public class RatingController {
    @Autowired
    RatingServiceInterface ratingServiceInterface;

    @PostMapping
    public ResponseEntity<Rating>createRating(@RequestBody Rating rating){
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingServiceInterface.createRating(rating));

    }

    @GetMapping("/all")
    public ResponseEntity<List<Rating>>getAll(){
        return ResponseEntity.ok(ratingServiceInterface.getAll());
    }

    @GetMapping("/UserId/{userId}")
    public ResponseEntity<List<Rating>>getByUserId(@PathVariable String userId){
        return ResponseEntity.ok(ratingServiceInterface.getByUserId(userId));
    }

    @GetMapping("/HotelId/{hotelId}")
    public ResponseEntity<List<Rating>>getByHotelId(@PathVariable String hotelId){
        return ResponseEntity.ok(ratingServiceInterface.getByHotelId(hotelId));
    }
}
