package com.example.Ratingservice.services;

import com.example.Ratingservice.entities.Rating;

import java.util.List;

public interface RatingServiceInterface {
    Rating createRating(Rating rating);

    List<Rating> getAll();
    List<Rating>getByUserId(String userId);

    List<Rating>getByHotelId(String hotelId);

}
